// Calculator logic for calculos.html
function fmt(n, d=2){ return Number.isFinite(n) ? Number(n).toFixed(d) : '—'; }

function computeAll(){
  const P = parseFloat(document.getElementById('power').value) || 0;
  const V = parseFloat(document.getElementById('voltage').value) || 0;
  const Ah = parseFloat(document.getElementById('ah').value) || 0;
  const cons = parseFloat(document.getElementById('consumption').value) || 0;
  const effPerc = parseFloat(document.getElementById('eff').value) || 100;
  const C = parseFloat(document.getElementById('c_rate').value) || 0.5;

  const eff = effPerc/100;

  const Wh = V * Ah;
  const range_km = cons > 0 ? (Wh / cons) : NaN;

  // corrente teórica e ajustada pela eficiência
  const I_theo = V>0 ? P / V : NaN;
  const I_batt = I_theo / eff; // accounting for efficiency losses

  // tempo de carga em horas (corrente de carga = C * Ah)
  const charge_current = C * Ah;
  const time_h = charge_current > 0 ? (Ah / charge_current) : NaN;

  // potência real na bateria para atingir P na roda (considerando eficiência)
  const P_batt = P / eff;

  const results = {
    V, Ah, Wh, range_km, I_theo, I_batt, P_batt, charge_current, time_h
  };

  const out = document.getElementById('results');
  out.innerHTML = `
    <h3>Resultados</h3>
    <p><strong>Energia da bateria:</strong> ${fmt(Wh,1)} Wh (V × Ah = ${fmt(V,2)} × ${fmt(Ah,2)})</p>
    <p><strong>Autonomia estimada:</strong> ${isFinite(range_km) ? fmt(range_km,1) + ' km' : '—'}</p>
    <p><strong>Corrente teórica necessária (I = P ÷ V):</strong> ${fmt(I_theo,3)} A</p>
    <p><strong>Corrente na bateria ajustada pela eficiência (${fmt(effPerc,0)}%):</strong> ${fmt(I_batt,3)} A</p>
    <p><strong>Potência retirada da bateria (considerando eficiência):</strong> ${fmt(P_batt,1)} W</p>
    <p><strong>Tempo de carga estimado (C = ${fmt(C,2)}):</strong> ${isFinite(time_h) ? fmt(time_h,2) + ' h' : '—'}</p>
    <p><strong>Corrente de carga (C × Ah):</strong> ${isFinite(charge_current) ? fmt(charge_current,2) + ' A' : '—'}</p>
  `;

  return results;
}

document.addEventListener('DOMContentLoaded', () => {
  const inputs = document.querySelectorAll('#calcForm input');
  inputs.forEach(i => i.addEventListener('input', computeAll));
  computeAll();

  document.getElementById('computePack').addEventListener('click', (e) => {
    e.preventDefault();
    const V = parseFloat(document.getElementById('voltage').value) || 0;
    const targetAh = parseFloat(document.getElementById('ah').value) || 0;
    const cellV = parseFloat(document.getElementById('cell_v').value) || 3.7;
    const cellAh = parseFloat(document.getElementById('cell_ah').value) || 3.0;

    const S = Math.round(V / cellV);
    const P = Math.ceil(targetAh / cellAh);
    const total = S * P;
    const packDiv = document.getElementById('packResult');
    packDiv.innerHTML = `<p>Configuração aproximada: <strong>${S}S${P}P</strong> → total de células: <strong>${total}</strong>.<br/>
    Verificação: tensão nominal ≈ ${(S*cellV).toFixed(2)} V; capacidade ≈ ${(P*cellAh).toFixed(2)} Ah.</p>`;
  });
});
