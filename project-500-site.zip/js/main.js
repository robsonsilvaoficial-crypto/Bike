// Pequenos comportamentos: realça o link ativo, futuro espaço para calculadora interativa.
document.addEventListener('DOMContentLoaded', () => {
  const links = document.querySelectorAll('.main-nav a');
  links.forEach(a => {
    try{
      if (location.href.endsWith(a.getAttribute('href')) || location.href === a.href) {
        a.style.textDecoration = 'underline';
      }
    }catch(e){}
  });
});
