# Projeto 500 — Conversão artesanal de bicicleta para e-bike 500 W

Este repositório contém um site estático (HTML/CSS/JS) pronto para publicação no GitHub Pages. O foco é um projeto artesanal para converter uma bicicleta comum em elétrica de 500 W — com cálculos, BOM e recomendações.

## Como publicar no GitHub Pages (resumo)
1. Crie um repositório no GitHub. Para publicar na URL `https://seu-usuario.github.io/`, nomeie o repositório `seu-usuario.github.io`.
2. Faça commit dos arquivos neste diretório (ou coloque em `docs/` se preferir).
3. Vá em Settings → Pages e habilite a branch `main` (ou `gh-pages`) como fonte.
4. Aguarde alguns minutos e a página estará disponível.

## Observações
- Trabalho técnico: se você não tem experiência com montagem de baterias, procure ajuda especializada.
- Consulte legislação local sobre conversões e limites de potência.
